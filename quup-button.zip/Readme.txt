=== quup Button ===
Contributors: apostylee
Donate link: 
Tags: quup,share,button,social network,turkish
Requires at least: 3.3
Tested up to: 3.5.1
Stable tag: 
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

http://quup.com social sharing button.

== Description ==

http://quup.com social sharing button. You can place this button to web sites or pages easly to show share count and quick sharing. Button enabled pages, display location, button styles and layout can be customized.

== Installation ==

1. Upload `quup-button.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress.